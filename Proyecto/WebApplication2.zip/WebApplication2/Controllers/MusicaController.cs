using Microsoft.AspNetCore.Mvc;
using WebApplication2.Context;
using WebApplication2.Models;
using System.Collections.Generic;

namespace WebApplication2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MusicaController : ControllerBase
    {
        private readonly AplicacionContexto _aplicacionContexto;

        public MusicaController(AplicacionContexto aplicacionContexto)
        {
            _aplicacionContexto = aplicacionContexto;
        }

        // POST: Crear una nueva canci�n
        [HttpPost]
        public IActionResult Post([FromBody] Musica musica)
        {
            _aplicacionContexto.Musicas.Add(musica);
            _aplicacionContexto.SaveChanges();
            return Ok(musica);
        }

        // GET: Obtener lista de canciones
        [HttpGet]
        public IEnumerable<Musica> Get()
        {
            var musicas = _aplicacionContexto.Musicas;
            return musicas;
        }

        // PUT: Modificar una canci�n existente
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Musica musica)
        {
            var musicaExistente = _aplicacionContexto.Musicas.Find(id);

            if (musicaExistente == null)
            {
                return NotFound(); // Canci�n no encontrada
            }

            musicaExistente.Titulo = musica.Titulo;
            musicaExistente.Genero = musica.Genero;
            musicaExistente.NumeroReproducciones = musica.NumeroReproducciones;

            _aplicacionContexto.Update(musicaExistente);
            _aplicacionContexto.SaveChanges();
            return Ok(musicaExistente);
        }

        // DELETE: Eliminar una canci�n
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var musica = _aplicacionContexto.Musicas.Find(id);

            if (musica == null)
            {
                return NotFound(); // Canci�n no encontrada
            }

            _aplicacionContexto.Musicas.Remove(musica);
            _aplicacionContexto.SaveChanges();
            return NoContent();
        }
    }
}
