using Microsoft.AspNetCore.Mvc;
using WebApplication2.Context;
using WebApplication2.Models;
using System.Collections.Generic;

namespace WebApplication2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DiscoController : ControllerBase
    {
        private readonly AplicacionContexto _aplicacionContexto;

        public DiscoController(AplicacionContexto aplicacionContexto)
        {
            _aplicacionContexto = aplicacionContexto;
        }

        // POST: Crear un nuevo disco
        [HttpPost]
        public IActionResult Post([FromBody] Disco disco)
        {
            _aplicacionContexto.Discos.Add(disco);
            _aplicacionContexto.SaveChanges();
            return Ok(disco);
        }

        // GET: Obtener lista de discos
        [HttpGet]
        public IEnumerable<Disco> Get()
        {
            var discos = _aplicacionContexto.Discos;
            return discos;
        }

        // PUT: Modificar un disco existente
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Disco disco)
        {
            var discoExistente = _aplicacionContexto.Discos.Find(id);

            if (discoExistente == null)
            {
                return NotFound(); // Disco no encontrado
            }

            discoExistente.Titulo = disco.Titulo;
            discoExistente.Autor = disco.Autor;
            discoExistente.A�o = disco.A�o;

            _aplicacionContexto.Update(discoExistente);
            _aplicacionContexto.SaveChanges();
            return Ok(discoExistente);
        }

        // DELETE: Eliminar un disco
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var disco = _aplicacionContexto.Discos.Find(id);

            if (disco == null)
            {
                return NotFound(); // Disco no encontrado
            }

            _aplicacionContexto.Discos.Remove(disco);
            _aplicacionContexto.SaveChanges();
            return NoContent();
        }
    }
}
