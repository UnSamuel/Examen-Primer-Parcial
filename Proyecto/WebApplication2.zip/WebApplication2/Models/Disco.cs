namespace WebApplication2.Models
{
    public class Disco
    {
        public int idDisco { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public int A�o { get; set; }

        // Propiedad de navegaci�n para la relaci�n con Musica
        public List<Musica> Musicas { get; set; }
    }
}